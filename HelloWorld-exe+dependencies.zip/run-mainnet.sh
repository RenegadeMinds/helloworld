#!/bin/sh -e

./hello \
  --xaya_rpc_url="http://__cookie__:62c7a564a2eea4b0e56b4ee9d0abdbb12c1a859139af4f3b045534bf5445c59d@localhost:8396" \
  --game_rpc_port=29050 \
  --storage_type=lmdb \
  --datadir=/tmp/xayagame
