git clone https://github.com/xaya/libxayagame.git
pacman -S autoconf-archive mingw-w64-x86_64-protobuf mingw-w64-x86_64-gtest mingw-w64-x86_64-gflags mingw-w64-x86_64-zeromq mingw-w64-x86_64-openssl mingw-w64-x86_64-glog mingw-w64-x86_64-lmdb mingw-w64-x86_64-lmdbxx mingw-w64-x86_64-sqlite3 mingw-w64-x86_64-libmicrohttpd
git clone https://github.com/jonathanmarvens/argtable2.git
cd argtable2
cmake . -G"MSYS Makefiles" -DCMAKE_INSTALL_PREFIX=$MINGW_PREFIX
make
make install
cp ./src/argtable2.h /home/../mingw64/include/argtable2.h
cd ..
git clone https://github.com/cinemast/libjson-rpc-cpp.git
cd libjson-rpc-cpp
git checkout a5bc3de024b78f0f8cab28416e402871708dfa92
cd ..
mv ./stubgeneratorfactory.cpp ./libjson-rpc-cpp/src/stubgenerator/
mv ./stubgeneratorfactory.h ./libjson-rpc-cpp/src/stubgenerator/
cd libjson-rpc-cpp
mkdir win32-deps
cd win32-deps
mkdir include
cd ..
cmake . -G"MSYS Makefiles" -DCMAKE_INSTALL_PREFIX=$MINGW_PREFIX -DREDIS_SERVER=NO -DREDIS_CLIENT=NO  -DCOMPILE_STUBGEN=YES -DCOMPILE_EXAMPLES=NO -DCOMPILE_TESTS=NO -DBUILD_STATIC_LIBS=YES -DHUNTER_ENABLED=YES
make
make install
cd dist
cp -r ./ /home/../mingw64/
cd ..
cd ..
mv ./lmdb.pc /home/../mingw64/lib/pkgconfig
mv ./libglog.pc /home/../mingw64/lib/pkgconfig
cd libxayagame
./autogen.sh
./configure
make
make install