pacman -Syuu
pacman -S base-devel git mingw-w64-x86_64-toolchain
pacman -S make mingw-w64-x86_64-cmake